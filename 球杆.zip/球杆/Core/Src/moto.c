/**
 ******************************************************************************
 * @file    moto.c
 * @brief   张大头 EMM42 闭环步进电机 PWM 脉冲驱动实现
 * @note    速度模式:
 *          - 通过调整定时器 ARR 改变脉冲频率 (频率 = 定时器时钟 / (ARR+1))
 *          - 定时器时钟 = 1MHz, ARR = (1,000,000 / 目标频率) - 1
 *          - 占空比固定 50%: CCR = (ARR+1) / 2
 *          - 方向由 DIR 引脚 GPIO 输出控制
 ******************************************************************************
 */

/* Includes ------------------------------------------------------------------*/
#include "moto.h"
#include "gpio.h"

/* Private variables ---------------------------------------------------------*/
static Moto_HandleTypeDef moto_handles[MOTO_NUM];

static float Moto_GetPulsesPerOutputRev(uint8_t motor_id)
{
    if (motor_id == MOTO_X) {
        return (float)MOTO_FULL_STEPS_PER_REV
             * (float)MOTO_X_MICROSTEP
             * MOTO_X_GEAR_RATIO;
    }
    return (float)MOTO_FULL_STEPS_PER_REV
         * (float)MOTO_Y_MICROSTEP
         * MOTO_Y_GEAR_RATIO;
}

static int32_t Moto_AngleToSteps(uint8_t motor_id, float angle_deg)
{
    float steps = angle_deg * Moto_GetPulsesPerOutputRev(motor_id) / 360.0f;
    return (steps >= 0.0f) ? (int32_t)(steps + 0.5f)
                           : (int32_t)(steps - 0.5f);
}

static float Moto_StepsToAngle(uint8_t motor_id, int32_t steps)
{
    return (float)steps * 360.0f / Moto_GetPulsesPerOutputRev(motor_id);
}

static uint32_t Moto_AngularSpeedToHz(uint8_t motor_id, float speed_dps)
{
    float pulse_hz;

    if (speed_dps < 0.0f) {
        speed_dps = -speed_dps;
    }
    pulse_hz = speed_dps * Moto_GetPulsesPerOutputRev(motor_id) / 360.0f;

    if (pulse_hz < (float)MOTO_SPEED_MIN) {
        pulse_hz = (float)MOTO_SPEED_MIN;
    }
    if (pulse_hz > (float)MOTO_SPEED_MAX) {
        pulse_hz = (float)MOTO_SPEED_MAX;
    }
    return (uint32_t)(pulse_hz + 0.5f);
}

/* -------------------------------------------------------------------------- */
/*                         静态辅助函数                                        */
/* -------------------------------------------------------------------------- */

/**
 * @brief  根据转速计算 ARR 值 (16位定时器, 最大65535)
 * @param  speed_hz  转速绝对值 (Hz)
 * @return ARR 值
 */
static uint16_t Moto_CalcARR(uint32_t speed_hz)
{
    uint32_t arr;

    if (speed_hz == 0) {
        return 0;
    }

    /* ARR = (定时器时钟 / 频率) - 1 */
    arr = (MOTO_TIM_CLK_HZ / speed_hz) - 1;

    /* 限幅 */
    if (arr > 65535) {
        arr = 65535;
    }
    if (arr < 1) {
        arr = 1;
    }

    return (uint16_t)arr;
}

/**
 * @brief  根据 ARR 计算 CCR (50% 占空比)
 * @param  arr  ARR 值
 * @return CCR 值
 */
static uint16_t Moto_CalcCCR(uint16_t arr)
{
    return (arr + 1) / 2;
}

/**
 * @brief  钳位转速到有效范围
 */
static int32_t Moto_ClampSpeed(int32_t speed_hz)
{
    if (speed_hz > MOTO_SPEED_MAX) {
        return MOTO_SPEED_MAX;
    }
    if (speed_hz < -MOTO_SPEED_MAX) {
        return -MOTO_SPEED_MAX;
    }
    /* 绝对值小于最低转速但非0时, 钳位到最低转速 */
    if (speed_hz > 0 && speed_hz < MOTO_SPEED_MIN) {
        return MOTO_SPEED_MIN;
    }
    if (speed_hz < 0 && speed_hz > -MOTO_SPEED_MIN) {
        return -MOTO_SPEED_MIN;
    }
    return speed_hz;
}

/**
 * @brief  根据转速符号获取方向
 */
static uint8_t Moto_GetDirection(int32_t speed_hz)
{
    return (speed_hz >= 0) ? MOTO_DIR_CW : MOTO_DIR_CCW;
}

/* -------------------------------------------------------------------------- */
/*                         公开函数实现                                        */
/* -------------------------------------------------------------------------- */

/**
 * @brief  初始化所有电机句柄
 * @note   必须在 HAL_TIM_PWM_Start 之前调用,或在 CubeMX 初始化之后
 */
void Moto_Init(void)
{
    /* --- X轴电机: TIM3_CH3 (PB0), DIR_X (PC4) --- */
    moto_handles[MOTO_X].id          = MOTO_X;
    moto_handles[MOTO_X].htim        = &htim3;
    moto_handles[MOTO_X].tim_channel = TIM_CHANNEL_4;
    moto_handles[MOTO_X].dir_port    = DIR_X_GPIO_Port;
    moto_handles[MOTO_X].dir_pin     = DIR_X_Pin;
    moto_handles[MOTO_X].target_speed = 0;
    moto_handles[MOTO_X].remaining_steps = 0;
    moto_handles[MOTO_X].current_steps = 0;
    moto_handles[MOTO_X].move_direction = 0;
    moto_handles[MOTO_X].angle_reference_valid = 0;
    moto_handles[MOTO_X].position_mode = 0;
    moto_handles[MOTO_X].running     = 0;

    

    /* 初始化方向引脚为低电平 (CW) */
    HAL_GPIO_WritePin(DIR_X_GPIO_Port, DIR_X_Pin, GPIO_PIN_RESET);
 
}

/**
 * @brief  设置电机转速 (速度模式)
 * @param  motor_id  电机ID
 * @param  speed_hz  转速 (Hz), 正=CW, 负=CCW, 0=停止
 *
 * 原理:
 *   PWM 频率 = 定时器时钟 / (ARR+1) = 1,000,000 / (ARR+1)
 *   所以 ARR = 1,000,000 / 频率 - 1
 *   CCR = (ARR+1)/2 保证 50% 占空比
 *
 * 例: 1000Hz → ARR = 1,000,000/1000 - 1 = 999, CCR = 500
 *     50kHz → ARR = 1,000,000/50000 - 1 = 19,   CCR = 10
 */
void Moto_SetSpeed(uint8_t motor_id, int32_t speed_hz)
{
    Moto_HandleTypeDef *m;
    uint16_t arr, ccr;
    uint32_t channel;

    /* 参数检查 */
    if (motor_id >= MOTO_NUM) {
        return;
    }
    m = &moto_handles[motor_id];

    /* 切换到连续速度模式前, 取消尚未完成的中断计步任务 */
    if (m->position_mode) {
        Moto_Stop(motor_id);
    }
    /* 连续速度模式不经过计步中断, 绝对角度参考随之失效 */
    m->angle_reference_valid = 0;

    /* 钳位转速 */
    speed_hz = Moto_ClampSpeed(speed_hz);
    m->target_speed = speed_hz;

    /* 转速为0 → 停止PWM输出 */
    if (speed_hz == 0) {
        Moto_Stop(motor_id);
        return;
    }

    channel = m->tim_channel;

    /* 1. 设置方向引脚 */
    if (Moto_GetDirection(speed_hz) == MOTO_DIR_CW) {
        HAL_GPIO_WritePin(m->dir_port, m->dir_pin, GPIO_PIN_RESET);
    } else {
        HAL_GPIO_WritePin(m->dir_port, m->dir_pin, GPIO_PIN_SET);
    }

    /* 2. 计算 ARR 和 CCR */
    arr = Moto_CalcARR((uint32_t)(speed_hz > 0 ? speed_hz : -speed_hz));
    ccr = Moto_CalcCCR(arr);

    /* 3. 更新定时器 ARR 和 CCR */
    __HAL_TIM_SET_AUTORELOAD(m->htim, arr);
    __HAL_TIM_SET_COMPARE(m->htim, channel, ccr);

    /* 4. 生成更新事件, 使新值立即生效 */
    m->htim->Instance->EGR = TIM_EGR_UG;

    /* 5. 如果之前是停止状态, 启动 PWM 输出 */
    if (!m->running) {
        HAL_TIM_PWM_Start(m->htim, channel);
        m->running = 1;
    }
}

/**
 * @brief  以PWM捕获比较中断统计脉冲并自动停止
 */
uint8_t Moto_MoveSteps(uint8_t motor_id, int32_t steps, uint32_t speed_hz)
{
    Moto_HandleTypeDef *m;
    uint32_t step_count;
    uint16_t arr, ccr;

    if (motor_id >= MOTO_NUM || steps == 0) {
        return 0;
    }

    
    if (speed_hz > MOTO_SPEED_MAX) {
        speed_hz = MOTO_SPEED_MAX;
    }

    m = &moto_handles[motor_id];
    Moto_Stop(motor_id);

    if (steps > 0) {
        HAL_GPIO_WritePin(m->dir_port, m->dir_pin, GPIO_PIN_RESET);
        step_count = (uint32_t)steps;
        m->move_direction = 1;
        m->target_speed = (int32_t)speed_hz;
    } else {
        HAL_GPIO_WritePin(m->dir_port, m->dir_pin, GPIO_PIN_SET);
        step_count = (uint32_t)(-(int64_t)steps);
        m->move_direction = -1;
        m->target_speed = -(int32_t)speed_hz;
    }

    arr = Moto_CalcARR(speed_hz);
    ccr = Moto_CalcCCR(arr);
    __HAL_TIM_SET_AUTORELOAD(m->htim, arr);
    __HAL_TIM_SET_COMPARE(m->htim, m->tim_channel, ccr);
    __HAL_TIM_SET_COUNTER(m->htim, 0);
    m->htim->Instance->EGR = TIM_EGR_UG;

    m->remaining_steps = step_count;
    m->position_mode = 1;
    m->running = 1;

    if (HAL_TIM_PWM_Start_IT(m->htim, m->tim_channel) != HAL_OK) {
        m->remaining_steps = 0;
        m->move_direction = 0;
        m->position_mode = 0;
        m->running = 0;
        m->target_speed = 0;
        return 0;
    }

    return 1;
}

uint8_t Moto_MoveRelativeAngle(uint8_t motor_id, float angle_deg,
                               float speed_dps)
{
    int32_t steps;
    uint32_t speed_hz;

    if (motor_id >= MOTO_NUM || speed_dps == 0.0f) {
        return 0;
    }

    steps = Moto_AngleToSteps(motor_id, angle_deg);
    if (steps == 0) {
        return 1;
    }
    speed_hz = Moto_AngularSpeedToHz(motor_id, speed_dps);
    return Moto_MoveSteps(motor_id, steps, speed_hz);
}

uint8_t Moto_GotoAngle(uint8_t motor_id, float target_angle_deg,
                       float speed_dps)
{
    Moto_HandleTypeDef *m;
    int32_t target_steps;
    int32_t delta_steps;
    uint32_t speed_hz;

    if (motor_id >= MOTO_NUM || speed_dps == 0.0f) {
        return 0;
    }
    m = &moto_handles[motor_id];
    if (!m->angle_reference_valid) {
        return 0;
    }

    target_steps = Moto_AngleToSteps(motor_id, target_angle_deg);
    delta_steps = target_steps - m->current_steps;
    if (delta_steps == 0) {
        return 1;
    }

    speed_hz = Moto_AngularSpeedToHz(motor_id, speed_dps);
    return Moto_MoveSteps(motor_id, delta_steps, speed_hz);
}

uint8_t Moto_SetCurrentAngle(uint8_t motor_id, float current_angle_deg)
{
    Moto_HandleTypeDef *m;

    if (motor_id >= MOTO_NUM) {
        return 0;
    }
    m = &moto_handles[motor_id];
    if (m->running) {
        return 0;
    }

    m->current_steps = Moto_AngleToSteps(motor_id, current_angle_deg);
    m->angle_reference_valid = 1;
    return 1;
}

float Moto_GetCurrentAngle(uint8_t motor_id)
{
    if (motor_id >= MOTO_NUM) {
        return 0.0f;
    }
    return Moto_StepsToAngle(motor_id, moto_handles[motor_id].current_steps);
}

uint8_t Moto_HasAngleReference(uint8_t motor_id)
{
    if (motor_id >= MOTO_NUM) {
        return 0;
    }
    return moto_handles[motor_id].angle_reference_valid;
}

/**
 * @brief  停止指定电机
 * @note   关闭 PWM 输出通道, 电机停止接收脉冲
 */
void Moto_Stop(uint8_t motor_id)
{
    Moto_HandleTypeDef *m;

    if (motor_id >= MOTO_NUM) {
        return;
    }
    m = &moto_handles[motor_id];

    if (m->position_mode) {
        HAL_TIM_PWM_Stop_IT(m->htim, m->tim_channel);
    } else {
        HAL_TIM_PWM_Stop(m->htim, m->tim_channel);
    }
    m->remaining_steps = 0;
    m->move_direction = 0;
    m->position_mode = 0;
    m->running = 0;
    m->target_speed = 0;
}

/**
 * @brief  紧急停止所有电机
 */
void Moto_EmergencyStop(void)
{
    Moto_Stop(MOTO_X);
    Moto_Stop(MOTO_Y);
}

/**
 * @brief  获取当前目标转速
 * @return 转速 (Hz)
 */
int32_t Moto_GetSpeed(uint8_t motor_id)
{
    if (motor_id >= MOTO_NUM) {
        return 0;
    }
    return moto_handles[motor_id].target_speed;
}

/**
 * @brief  查询电机是否在运行
 * @return 1=运行中, 0=停止
 */
uint8_t Moto_IsRunning(uint8_t motor_id)
{
    if (motor_id >= MOTO_NUM) {
        return 0;
    }
    return moto_handles[motor_id].running;
}

uint32_t Moto_GetRemainingSteps(uint8_t motor_id)
{
    if (motor_id >= MOTO_NUM) {
        return 0;
    }
    return moto_handles[motor_id].remaining_steps;
}

/**
 * @brief  每个PWM周期触发一次, 用于有限步数运动计数
 */
void HAL_TIM_PWM_PulseFinishedCallback(TIM_HandleTypeDef *htim)
{
    uint8_t i;
    Moto_HandleTypeDef *m;

    for (i = 0; i < MOTO_NUM; i++) {
        m = &moto_handles[i];
        if (m->htim != htim || !m->position_mode || !m->running) {
            continue;
        }

        if (m->remaining_steps > 0) {
            m->remaining_steps--;
            m->current_steps += m->move_direction;
        }

        if (m->remaining_steps == 0) {
            HAL_TIM_PWM_Stop_IT(m->htim, m->tim_channel);
            m->move_direction = 0;
            m->position_mode = 0;
            m->running = 0;
            m->target_speed = 0;
        }
        break;
    }
}
