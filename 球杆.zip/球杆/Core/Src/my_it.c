#include "my_it.h"
#include "math.h"

uint16_t tmr_10ms;
uint16_t tmr_5ms;
uint16_t tmr_1000ms;
uint8_t flag_tmr0=0;
unsigned int time;


float err;

void TIM1_UP_Call(TIM_HandleTypeDef *htim)
{
	err = zhongxin - x_center;
//	mode_control();
	if (htim->Instance == TIM1) 
    {
		time++;
		if (new_data) 
		{
			new_data = 0; 
			dianji_pid();		
		    dianji_flag=1;
			if(time>=10)
			{
				time=0;
				speed_pid();
	//		  HAL_GPIO_TogglePin(led_GPIO_Port,led_Pin);
			}
		}
        tmr_10ms++;
		tmr_5ms++;
		if(tmr_10ms>=10)
		{
			tmr_10ms = 0;
			printf("%f,%d,%d\r\n",dianji.out,zhongxin,x_center);
			
			
//				oscilloscope_data.data[0] = out;
//				oscilloscope_data.data[1] = stepmotor_pid.Ki;
//				oscilloscope_data.data[2] = stepmotor_pid.integral;
//				oscilloscope_data.data[3] = x_center;
//				seekfree_assistant_oscilloscope_send(&oscilloscope_data);
				
		}
		if(tmr_5ms >= 5)
		{
			tmr_5ms = 0;
//				motor_control_update();
		}
		if(fabs(err) <= 0.5f)
		{
			tmr_1000ms++;
			if(tmr_1000ms >= 1000)
			{
				flag_tmr0 = 1;
			}
		}
		__HAL_TIM_CLEAR_IT(htim, TIM_IT_UPDATE);
    }
}
