
#include "main.h"
#include "stdlib.h"

pid dianji;
pid speed;
unsigned char dianji_flag=0;
unsigned char mode_menu=9;
int8_t flag_0=0;

int32_t zhongxin = 159;

signed int current_weizhi,last_weizhi; 

void speed_pid(void)
{
	speed.kp=0.01;
	speed.ki=0.001
	;
	current_weizhi=x_center;
	speed.actual=current_weizhi-last_weizhi;
	speed.error1=speed.error0;
	speed.error0=speed.target-speed.actual;
	speed.errorint+=speed.error0;
	if(speed.errorint>=30)speed.errorint=30;
	if(speed.errorint<=-30)speed.errorint=-30;
	speed.out=speed.kp*speed.error0+speed.ki*speed.errorint+speed.kd*(speed.error0-speed.error1);
	last_weizhi=current_weizhi;
}

void dianji_pid(void)
{
	dianji.kp=0.4;
	dianji.ki=0.0;
	dianji.kd=10;
	dianji.target=zhongxin;
	dianji.actual=x_center;
	dianji.error1=dianji.error0;
	dianji.error0=dianji.target-dianji.actual;
	dianji.errorint+=dianji.error0;
	if(dianji.errorint>=50)
	{
		dianji.errorint=50;
	}
	if(dianji.errorint<=-50)
	{
		dianji.errorint=-50;
	}
	dianji.out=dianji.kp*dianji.error0+dianji.ki*dianji.errorint+dianji.kd*(dianji.error0-dianji.error1)-speed.out;
//	if(dianji.error0<10&&dianji.error0>-10)
//	{
//		dianji.error0=0;
//	}
	if(abs(dianji.out) < 5)
	{
		dianji.out = dianji.out * 3;
	}
	if(dianji.out>=120)
	{
		dianji.out=120;
	}
	if(dianji.out<=-120)
	{
		dianji.out=-120;
	}
}
void menu()
{
			if(HAL_GPIO_ReadPin (GPIOA ,GPIO_PIN_6 )==GPIO_PIN_RESET)///////////////////////////С���۷�
		{
			mode_menu=0;
		}
					if(HAL_GPIO_ReadPin (GPIOB ,GPIO_PIN_5 )==GPIO_PIN_RESET)
		{
			mode_menu=1;
		}
					if(HAL_GPIO_ReadPin (GPIOG ,GPIO_PIN_7 )==GPIO_PIN_RESET)
		{
			mode_menu=2;
		}
					if(HAL_GPIO_ReadPin (GPIOA ,GPIO_PIN_11 )==GPIO_PIN_RESET)
		{
			mode_menu=3;
		}
}


void panduan()
{
	if(mode_menu == 0)
	{
		if(flag_0 == 1)
		{
			zhongxin = 75;  //75
		}
		else
		{
			zhongxin = 250;  //5cm�̶�   224
			if(x_center >= 224)
			{
				flag_0 = 1;
			}
		}
	}
}



