/**
 ******************************************************************************
 * @file    moto.h
 * @brief   张大头 EMM42 闭环步进电机 PWM 脉冲驱动
 * @note    速度模式: 通过改变 PWM 频率(ARR)控制转速, 50%占空比脉冲
 *          - X轴电机: TIM3_CH1 (PA6), DIR_X (PA4)
 *          - Y轴电机: TIM4_CH1 (PB6), DIR_Y (PB7)
 *          - 定时器时钟: 84MHz / (83+1) = 1MHz
 *          - 转速范围: 100Hz ~ 50,000Hz (脉冲/秒)
 ******************************************************************************
 */
#ifndef __MOTO_H__
#define __MOTO_H__

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "tim.h"

#define DIR_X_GPIO_Port GPIOC
#define DIR_X_Pin       GPIO_PIN_5

/* Motor IDs -----------------------------------------------------------------*/
#define MOTO_X              0   /* X轴电机 (TIM3, PA6, DIR=PA4) */
#define MOTO_Y              1   /* Y轴电机 (TIM4, PB6, DIR=PB7) */
#define MOTO_NUM            2   /* 电机数量 */

/* Direction macros ----------------------------------------------------------*/
#define MOTO_DIR_CW         0   /* 顺时针 (正向) */
#define MOTO_DIR_CCW        1   /* 逆时针 (反向) */

/* Speed parameters ----------------------------------------------------------*/
#define MOTO_SPEED_MIN          0     /* 最低转速 (Hz) */
#define MOTO_SPEED_MAX          10000   /* 最高转速 (Hz) */
#define MOTO_SPEED_DEFAULT      0    /* 默认转速 (Hz) */
#define MOTO_TIM_CLK_HZ         1000000 /* 定时器计数时钟 = 1MHz */

/* Angle conversion ---------------------------------------------------------*/
/* These values must match the subdivision configured in the X42 driver. */
#define MOTO_FULL_STEPS_PER_REV 200U
#define MOTO_X_MICROSTEP        16U
#define MOTO_Y_MICROSTEP        16U

/* Motor revolutions / output-shaft revolution.
 * Example: 20-tooth motor gear driving a 60-tooth output gear => 3.0f.
 */
#define MOTO_X_GEAR_RATIO       1.0f
#define MOTO_Y_GEAR_RATIO       1.0f

/**
 * @brief 电机控制句柄结构体
 */
typedef struct {
    uint8_t           id;            /* 电机ID (MOTO_X / MOTO_Y) */
    TIM_HandleTypeDef *htim;         /* 定时器句柄 */
    uint32_t          tim_channel;   /* 定时器PWM通道 */
    GPIO_TypeDef      *dir_port;     /* 方向引脚端口 */
    uint16_t          dir_pin;       /* 方向引脚编号 */
    volatile int32_t  target_speed;  /* 目标转速 (Hz), 正=CW, 负=CCW */
    volatile uint32_t remaining_steps; /* 位置模式剩余脉冲数 */
    volatile int32_t  current_steps; /* 相对软件零点的累计脉冲位置 */
    volatile int8_t   move_direction; /* 当前计步方向: +1/-1/0 */
    volatile uint8_t  angle_reference_valid; /* 软件角度零点是否有效 */
    volatile uint8_t  position_mode; /* 1=中断计步模式, 0=连续速度模式 */
    volatile uint8_t  running;       /* 运行状态: 1=运行中, 0=停止 */
} Moto_HandleTypeDef;

/* Public function prototypes ------------------------------------------------*/

/**
 * @brief  初始化所有电机 (必须在 MX_TIM3_Init / MX_TIM4_Init 之后调用)
 */
void Moto_Init(void);

/**
 * @brief  设置电机转速 (速度模式, 立即生效)
 * @param  motor_id  电机ID: MOTO_X 或 MOTO_Y
 * @param  speed_hz  转速 (Hz), 正值=CW, 负值=CCW, 0=停止
 * @note   超出 MOTO_SPEED_MIN ~ MOTO_SPEED_MAX 范围会被钳位
 */
void Moto_SetSpeed(uint8_t motor_id, int32_t speed_hz);

/**
 * @brief  停止指定电机 (PWM输出关闭)
 */
void Moto_Stop(uint8_t motor_id);

/**
 * @brief  获取当前转速
 * @return 转速 (Hz), 正=CW, 负=CCW, 0=停止
 */
int32_t Moto_GetSpeed(uint8_t motor_id);

/**
 * @brief  查询电机是否在运行
 * @return 1=运行中, 0=停止
 */
uint8_t Moto_IsRunning(uint8_t motor_id);

/**
 * @brief  转到相对软件零点的绝对输出轴角度
 * @note   必须先调用 Moto_SetCurrentAngle 建立角度参考
 */
uint8_t Moto_GotoAngle(uint8_t motor_id, float target_angle_deg,
                       float speed_dps);

uint8_t Moto_SetCurrentAngle(uint8_t motor_id, float current_angle_deg);

/* USER CODE BEGIN Prototypes */

/* USER CODE END Prototypes */

#ifdef __cplusplus
}
#endif

#endif /* __MOTO_H__ */
