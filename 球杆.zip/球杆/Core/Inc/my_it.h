#ifndef  _MY_IT_H
#define  _MY_IT_H
#include "main.h"

extern uint16_t tmr_10ms;

extern uint8_t flag_tmr0;

void TIM1_UP_Call(TIM_HandleTypeDef *htim);

#endif

