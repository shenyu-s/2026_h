#ifndef __MY_UART_H__
#define __MY_UART_H__
#include "main.h"

//==============================================================================
// 1. ����
//==============================================================================
#define BUF_LEN_MAX     64          // ���ջ�������С
#define PKG_HEADER1     0xAA
#define PKG_HEADER2     0xBB
#define PKG_LEN         4           // ���ݰ��ܳ���


extern uint8_t Rx_Buff[];
extern uint16_t x_center;
extern uint8_t new_data;

void my_uart3_callback(void);

#endif /* __MY_UART_H__ */
