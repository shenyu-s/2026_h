

#ifndef __control_h
#define __control_h

#include "main.h"


typedef struct 
{
	float kp;
	float ki;
	float kd;
	float error0;
	float error1;
	float error2;
	float errorint;
	float target;
	float actual;
	float out;
}pid;

extern pid dianji;
extern pid speed;
extern unsigned char dianji_flag;
extern unsigned char mode_menu;

extern int32_t zhongxin;

void speed_pid(void);
void dianji_pid(void);
void menu(void);
void panduan(void);

#endif
